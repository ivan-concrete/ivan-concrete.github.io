package main

import (
	"fmt"
	"os"
	"strings"

	"github.com/charmbracelet/bubbles/textinput"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

type Slide struct {
	Title   string
	Content string
}

type Model struct {
	slides       []Slide
	currentIndex int
	mode         int // 0 - просмотр, 1 - заголовок, 2 - контент, 3 - ввод имени файла (сохр), 4 - ввод имени файла (открытие)
	
	titleInput   textinput.Model
	contentInput textinput.Model
	fileInput    textinput.Model
	
	filename     string
	statusMsg    string
}

func initialModel(filepath string) Model {
	slides := []Slide{
		{Title: "Добро пожаловать в TermPoint", Content: "Нажмите '+' — добавить новый слайд\nНажмите '1' — править заголовок\nНажмите '2' — править текст\nНажмите 'a' — сохранить как"},
		{Title: "Второй слайд", Content: "Редактируйте на любых языках."},
	}

	if filepath != "" {
		if data, err := os.ReadFile(filepath); err == nil {
			parsed := parsePresentation(string(data))
			if len(parsed) > 0 {
				slides = parsed
			}
		}
	}

	tiTitle := textinput.New()
	tiTitle.CharLimit = 100
	tiTitle.Width = 50

	tiContent := textinput.New()
	tiContent.CharLimit = 500
	tiContent.Width = 60

	tiFile := textinput.New()
	tiFile.Placeholder = "например: presentation.tpt"
	tiFile.CharLimit = 100
	tiFile.Width = 40

	if len(slides) > 0 {
		tiTitle.SetValue(slides[0].Title)
		tiContent.SetValue(slides[0].Content)
	}

	activeFile := filepath
	if activeFile == "" {
		activeFile = "presentation.tpt"
	}

	return Model{
		slides:       slides,
		currentIndex: 0,
		titleInput:   tiTitle,
		contentInput: tiContent,
		fileInput:    tiFile,
		filename:     activeFile,
	}
}

func parsePresentation(raw string) []Slide {
	parts := strings.Split(raw, "---")
	var result []Slide
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p == "" {
			continue
		}
		lines := strings.SplitN(p, "\n", 2)
		title := strings.TrimPrefix(lines[0], "# ")
		content := ""
		if len(lines) > 1 {
			content = lines[1]
		}
		result = append(result, Slide{Title: title, Content: content})
	}
	return result
}

func (m Model) Init() tea.Cmd {
	return textinput.Blink
}

func (m Model) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmd tea.Cmd

	switch msg := msg.(type) {
	case tea.KeyMsg:
		// 1. Редактирование заголовка
		if m.mode == 1 {
			switch msg.String() {
			case "enter", "esc", "tab":
				m.slides[m.currentIndex].Title = m.titleInput.Value()
				m.mode = 0
				m.titleInput.Blur()
				m.statusMsg = "Заголовок изменен"
				return m, nil
			}
			m.titleInput, cmd = m.titleInput.Update(msg)
			m.slides[m.currentIndex].Title = m.titleInput.Value()
			return m, cmd
		}

		// 2. Редактирование контента
		if m.mode == 2 {
			switch msg.String() {
			case "esc", "tab":
				m.slides[m.currentIndex].Content = m.contentInput.Value()
				m.mode = 0
				m.contentInput.Blur()
				m.statusMsg = "Текст изменен"
				return m, nil
			}
			m.contentInput, cmd = m.contentInput.Update(msg)
			m.slides[m.currentIndex].Content = m.contentInput.Value()
			return m, cmd
		}

		// 3. Ввод имени файла для СОХРАНЕНИЯ ("Сохранить как")
		if m.mode == 3 {
			switch msg.String() {
			case "esc":
				m.mode = 0
				m.fileInput.Blur()
				m.statusMsg = "Сохранение отменено"
				return m, nil
			case "enter":
				newName := strings.TrimSpace(m.fileInput.Value())
				if newName != "" {
					m.filename = newName
					m.saveToFile()
				}
				m.mode = 0
				m.fileInput.Blur()
				return m, nil
			}
			m.fileInput, cmd = m.fileInput.Update(msg)
			return m, cmd
		}

		// 4. Ввод имени файла для ОТКРЫТИЯ
		if m.mode == 4 {
			switch msg.String() {
			case "esc":
				m.mode = 0
				m.fileInput.Blur()
				m.statusMsg = "Открытие отменено"
				return m, nil
			case "enter":
				targetFile := strings.TrimSpace(m.fileInput.Value())
				if targetFile != "" {
					if data, err := os.ReadFile(targetFile); err == nil {
						parsed := parsePresentation(string(data))
						if len(parsed) > 0 {
							m.slides = parsed
							m.currentIndex = 0
							m.filename = targetFile
							m.titleInput.SetValue(m.slides[0].Title)
							m.contentInput.SetValue(m.slides[0].Content)
							m.statusMsg = "Открыт файл: " + targetFile
						}
					} else {
						m.statusMsg = "Ошибка: файл не найден"
					}
				}
				m.mode = 0
				m.fileInput.Blur()
				return m, nil
			}
			m.fileInput, cmd = m.fileInput.Update(msg)
			return m, cmd
		}

		// Обычный режим просмотра
		switch msg.String() {
		case "q", "ctrl+c":
			return m, tea.Quit
		case "right", "n":
			if m.currentIndex < len(m.slides)-1 {
				m.currentIndex++
				m.titleInput.SetValue(m.slides[m.currentIndex].Title)
				m.contentInput.SetValue(m.slides[m.currentIndex].Content)
			}
		case "left", "p":
			if m.currentIndex > 0 {
				m.currentIndex--
				m.titleInput.SetValue(m.slides[m.currentIndex].Title)
				m.contentInput.SetValue(m.slides[m.currentIndex].Content)
			}
		case "+":
			// ДОБАВЛЕНИЕ НОВОГО СЛАЙДА
			newSlide := Slide{
				Title:   fmt.Sprintf("Слайд %d", len(m.slides)+1),
				Content: "Введите текст нового слайда...",
			}
			// Вставляем слайд сразу после текущего
			m.slides = append(m.slides[:m.currentIndex+1], append([]Slide{newSlide}, m.slides[m.currentIndex+1:]...)...)
			m.currentIndex++ // Переходим на созданный слайд
			
			// Обновляем инпуты и сразу открываем режим редактирования текста
			m.titleInput.SetValue(m.slides[m.currentIndex].Title)
			m.contentInput.SetValue(m.slides[m.currentIndex].Content)
			m.mode = 2
			m.contentInput.Focus()
			m.statusMsg = "Создан новый слайд. Введите текст и нажмите Esc."
			return m, textinput.Blink

		case "1":
			m.mode = 1
			m.titleInput.Focus()
			m.statusMsg = "Правка заголовка [Enter — ок]"
			return m, textinput.Blink
		case "2":
			m.mode = 2
			m.contentInput.Focus()
			m.statusMsg = "Правка текста [Esc — ок]"
			return m, textinput.Blink
		case "s":
			m.saveToFile()
		case "a":
			m.mode = 3
			m.fileInput.SetValue(m.filename)
			m.fileInput.Focus()
			m.statusMsg = "Введите имя файла для сохранения:"
			return m, textinput.Blink
		case "o":
			m.mode = 4
			m.fileInput.SetValue("")
			m.fileInput.Focus()
			m.statusMsg = "Введите имя файла для открытия:"
			return m, textinput.Blink
		}
	}

	return m, cmd
}

func (m *Model) saveToFile() {
	m.slides[m.currentIndex].Title = m.titleInput.Value()
	m.slides[m.currentIndex].Content = m.contentInput.Value()

	var sb strings.Builder
	for _, s := range m.slides {
		sb.WriteString("# " + s.Title + "\n")
		sb.WriteString(s.Content + "\n---\n")
	}
	err := os.WriteFile(m.filename, []byte(sb.String()), 0644)
	if err != nil {
		m.statusMsg = "Ошибка сохранения: " + err.Error()
	} else {
		m.statusMsg = "Сохранено в: " + m.filename
	}
}

func (m Model) View() string {
	if len(m.slides) == 0 {
		return "Нет слайдов"
	}

	titleStyle := lipgloss.NewStyle().
		Bold(true).
		Foreground(lipgloss.Color("205")).
		Border(lipgloss.NormalBorder()).
		BorderBottom(true).
		Padding(0, 1)

	contentStyle := lipgloss.NewStyle().
		Foreground(lipgloss.Color("252")).
		Padding(1, 2)

	boxStyle := lipgloss.NewStyle().
		Border(lipgloss.RoundedBorder()).
		BorderForeground(lipgloss.Color("63")).
		Width(70).
		Height(12)

	var titleView string
	if m.mode == 1 {
		titleView = m.titleInput.View()
	} else {
		titleView = m.slides[m.currentIndex].Title
	}

	var contentView string
	if m.mode == 2 {
		contentView = m.contentInput.View()
	} else {
		contentView = m.slides[m.currentIndex].Content
	}

	status := m.statusMsg
	if m.mode == 3 || m.mode == 4 {
		status = "Имя файла: " + m.fileInput.View() + " [Enter — подтвердить, Esc — отмена]"
	} else if status == "" {
		status = fmt.Sprintf(" Файл: %s | Слайд %d/%d | [+] Новый | [1] Заголовок | [2] Текст | [s] Сохр | [o] Открыть | [q] Выход ",
			m.filename, m.currentIndex+1, len(m.slides))
	}

	slideContent := fmt.Sprintf("%s\n\n%s",
		titleStyle.Render(titleView),
		contentStyle.Render(contentView),
	)

	renderedBox := boxStyle.Render(slideContent)
	footerStyle := lipgloss.NewStyle().Foreground(lipgloss.Color("240")).Italic(true)

	return lipgloss.JoinVertical(
		lipgloss.Center,
		"\n",
		renderedBox,
		"\n",
		footerStyle.Render(status),
	)
}

func main() {
	arg := ""
	if len(os.Args) > 1 {
		arg = os.Args[1]
	}

	p := tea.NewProgram(initialModel(arg), tea.WithAltScreen())
	if _, err := p.Run(); err != nil {
		fmt.Printf("Ошибка: %v\n", err)
		os.Exit(1)
	}
}