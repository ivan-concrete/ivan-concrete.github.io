package main

import (
	"fmt"
	"io"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"unicode/utf8"

	"github.com/gdamore/tcell/v2"
	"github.com/rivo/tview"
)

var (
	bg     = tcell.NewHexColor(0x008080)
	border = tcell.NewHexColor(0x00FFFF)
	title  = tcell.NewHexColor(0xFFFF00)
	exe    = tcell.NewHexColor(0x00FF00)
	app    *tview.Application
	left   *FilePanel
	right  *FilePanel
	pages  *tview.Pages
)

const (
	pageView  = "view"
	pageForm  = "form"
	pageModal = "modal"
)

type FilePanel struct {
	*tview.Table
	dir string
}

func NewFilePanel(dir string) *FilePanel {
	t := tview.NewTable().SetSelectable(true, false)
	t.SetBorder(true).SetTitleColor(border).SetBorderColor(border).SetBackgroundColor(bg)
	t.SetSelectedStyle(tcell.StyleDefault.Foreground(tcell.ColorBlack).Background(border))

	absDir, err := filepath.Abs(dir)
	if err != nil {
		absDir = dir
	}

	fp := &FilePanel{Table: t, dir: absDir}
	fp.Refresh()

	// Перехват фокуса при клике мышкой по панели
	t.SetMouseCapture(func(action tview.MouseAction, event *tcell.EventMouse) (tview.MouseAction, *tcell.EventMouse) {
		if action == tview.MouseLeftClick && !t.HasFocus() {
			app.SetFocus(t)
		}
		return action, event
	})

	t.SetSelectedFunc(func(r, c int) {
		cell := t.GetCell(r, c)
		if cell == nil || r == 0 {
			return
		}
		name := cell.Text

		if name == ".." {
			fp.dir = filepath.Dir(fp.dir)
			fp.Refresh()
			t.Select(1, 0)
			return
		}

		targetPath := filepath.Join(fp.dir, name)
		if fi, err := os.Stat(targetPath); err == nil {
			if fi.IsDir() {
				fp.dir = targetPath
				fp.Refresh()
				t.Select(1, 0)
			} else {
				openWithOS(targetPath) // Открытие локального файла системой
			}
		}
	})
	return fp
}

// Избегаем выбора служебных строк (назад, ошибки)
func (fp *FilePanel) selectedName() string {
	r, _ := fp.GetSelection()
	if r == 0 {
		return ""
	}
	cell := fp.GetCell(r, 0)
	if cell == nil || cell.Text == ".." || strings.HasPrefix(cell.Text, "Ошибка") {
		return ""
	}
	return cell.Text
}

func (fp *FilePanel) Refresh() {
	prevRow, _ := fp.GetSelection()

	fp.Clear()
	fp.SetTitle(fmt.Sprintf("─── %s ───", fp.dir))

	entries, err := os.ReadDir(fp.dir)
	if err != nil {
		// Ошибка доступа — выводим ".." для возврата
		fp.SetCell(0, 0, tview.NewTableCell("Name").SetTextColor(title).SetSelectable(false))
		fp.SetCell(1, 0, tview.NewTableCell("..").SetTextColor(tcell.ColorYellow))
		fp.SetCell(2, 0, tview.NewTableCell("Ошибка чтения (Нет доступа)").SetTextColor(tcell.ColorRed).SetSelectable(false))
		fp.Select(1, 0)
		return
	}

	sort.Slice(entries, func(i, j int) bool {
		di, dj := entries[i].IsDir(), entries[j].IsDir()
		if di != dj {
			return di
		}
		return strings.ToLower(entries[i].Name()) < strings.ToLower(entries[j].Name())
	})

	fp.SetCell(0, 0, tview.NewTableCell("Name").SetTextColor(title).SetSelectable(false))
	fp.SetCell(1, 0, tview.NewTableCell("..").SetTextColor(tcell.ColorYellow))

	for i, entry := range entries {
		color := tcell.ColorWhite

		if entry.IsDir() {
			color = tcell.ColorYellow
		} else {
			ext := filepath.Ext(entry.Name())
			isExe := ext == ".exe" || ext == ".cmd" || ext == ".bat"

			// На Unix-системах лениво проверяем права на запуск (без лишних вызовов stat на Windows)
			if !isExe && runtime.GOOS != "windows" {
				if info, err := entry.Info(); err == nil {
					isExe = info.Mode()&0111 != 0
				}
			}

			if isExe {
				color = exe
			}
		}
		fp.SetCell(i+2, 0, tview.NewTableCell(entry.Name()).SetTextColor(color))
	}

	rows := fp.GetRowCount()
	if rows == 0 {
		return
	}
	newRow := prevRow
	if newRow >= rows {
		newRow = rows - 1
	}
	if newRow < 1 {
		newRow = 1
	}
	fp.Select(newRow, 0)
}

// openWithOS нужен ТОЛЬКО для открытия локальных файлов (картинки, доки) через систему по Enter
func openWithOS(p string) {
	var c *exec.Cmd
	switch runtime.GOOS {
	case "windows":
		c = exec.Command("rundll32", "url.dll,FileProtocolHandler", p)
	case "darwin":
		c = exec.Command("open", p)
	case "linux":
		c = exec.Command("xdg-open", p)
	default:
		return
	}
	c.Stdout = nil
	c.Stderr = nil
	_ = c.Start()
}

func editFile(path string) {
	editor := os.Getenv("EDITOR")
	if editor == "" {
		if runtime.GOOS == "windows" {
			editor = "notepad"
		} else {
			editor = "vi"
		}
	}
	app.Suspend(func() {
		c := exec.Command(editor, path)
		c.Stdin = os.Stdin
		c.Stdout = os.Stdout
		c.Stderr = os.Stderr
		_ = c.Run()
	})
	left.Refresh()
	right.Refresh()
}

func copyFile(src, dst string) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()

	out, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer out.Close()

	if _, err := io.Copy(out, in); err != nil {
		return err
	}
	info, err := os.Stat(src)
	if err == nil {
		_ = os.Chmod(dst, info.Mode())
	}
	return nil
}

func copyPath(src, dst string) error {
	info, err := os.Stat(src)
	if err != nil {
		return err
	}
	if !info.IsDir() {
		return copyFile(src, dst)
	}

	if err := os.MkdirAll(dst, info.Mode()); err != nil {
		return err
	}
	entries, err := os.ReadDir(src)
	if err != nil {
		return err
	}
	for _, e := range entries {
		s := filepath.Join(src, e.Name())
		d := filepath.Join(dst, e.Name())
		if err := copyPath(s, d); err != nil {
			return err
		}
	}
	return nil
}

func closeOverlay(id string, focus tview.Primitive) {
	pages.RemovePage(id)
	app.SetFocus(focus)
}

func showMessage(text string, back tview.Primitive) {
	m := tview.NewModal().
		SetText(text).
		AddButtons([]string{"OK"}).
		SetDoneFunc(func(int, string) {
			closeOverlay(pageModal, back)
		})
	m.SetBackgroundColor(bg).SetBorderColor(border)
	pages.AddPage(pageModal, m, true, true)
	app.SetFocus(m)
}

func showConfirm(text string, back tview.Primitive, onYes func()) {
	m := tview.NewModal().
		SetText(text).
		AddButtons([]string{"Да", "Нет"}).
		SetDoneFunc(func(idx int, lbl string) {
			closeOverlay(pageModal, back)
			if lbl == "Да" {
				onYes()
			}
		})
	m.SetBackgroundColor(bg).SetBorderColor(border)
	pages.AddPage(pageModal, m, true, true)
	app.SetFocus(m)
}

func showHelp(back tview.Primitive) {
	data, err := os.ReadFile("luz.hlp")
	txt := string(data)
	if err != nil {
		txt = "F1   Помощь\nF3   Просмотр\nF4   Редактировать\nF5   Копировать\nF6   Переименовать\nF7   Новая папка\nF8   Удалить\nTab  Переключить панель\nF10  Выход\n\n(luz.hlp не найден, показана дефолтная справка)"
	}

	v := tview.NewTextView().SetText(txt)
	v.SetBorder(true).SetTitle(" Помощь (Esc) ").SetTitleColor(title).SetBackgroundColor(bg)
	v.SetInputCapture(func(e *tcell.EventKey) *tcell.EventKey {
		if e.Key() == tcell.KeyEscape {
			closeOverlay(pageView, back)
		}
		return e
	})
	pages.AddPage(pageView, v, true, true)
	app.SetFocus(v)
}

func showInput(formTitle, label, initial string, back tview.Primitive, onOK func(string)) {
	f := tview.NewForm()
	f.SetBackgroundColor(bg)
	f.AddInputField(label, initial, 40, nil, nil)
	f.SetBorder(true).SetTitle(" " + formTitle + " ").SetTitleColor(title).SetBackgroundColor(bg)
	f.AddButton("ОК", func() {
		val := f.GetFormItem(0).(*tview.InputField).GetText()
		closeOverlay(pageForm, back)
		if val != "" {
			onOK(val)
		}
	})
	f.AddButton("Отмена", func() {
		closeOverlay(pageForm, back)
	})

	grid := tview.NewGrid().
		SetRows(0, 7, 0).
		SetColumns(0, 50, 0).
		AddItem(f, 1, 1, 1, 1, 0, 0, true)

	pages.AddPage(pageForm, grid, true, true)
	app.SetFocus(f)
}

func getActive() *FilePanel {
	if left.HasFocus() {
		return left
	}
	return right
}

func getInactive() *FilePanel {
	if left.HasFocus() {
		return right
	}
	return left
}

func panelHasFocus() bool {
	return left.HasFocus() || right.HasFocus()
}

func handleFKeys(key tcell.Key) {
	if !panelHasFocus() {
		return
	}

	p := getActive()
	name := p.selectedName()

	switch key {
	case tcell.KeyF1:
		showHelp(p)

	case tcell.KeyF3:
		if name == "" {
			return
		}
		target := filepath.Join(p.dir, name)
		if fi, err := os.Stat(target); err == nil && fi.IsDir() {
			return
		}

		data, err := os.ReadFile(target)
		txt := string(data)
		if err != nil {
			txt = "Ошибка чтения файла."
		} else if len(data) > 20480 {
			cut := 20480
			for cut > 0 && !utf8.RuneStart(data[cut]) {
				cut--
			}
			txt = string(data[:cut]) + "\n...[Обрезано для экономии памяти]"
		}

		v := tview.NewTextView().SetText(txt)
		v.SetBorder(true).SetTitle(" " + name + " (Esc) ").SetTitleColor(title).SetBackgroundColor(bg)
		v.SetInputCapture(func(e *tcell.EventKey) *tcell.EventKey {
			if e.Key() == tcell.KeyEscape {
				closeOverlay(pageView, p)
			}
			return e
		})
		pages.AddPage(pageView, v, true, true)
		app.SetFocus(v)

	case tcell.KeyF4:
		if name == "" {
			return
		}
		target := filepath.Join(p.dir, name)
		if fi, err := os.Stat(target); err == nil && fi.IsDir() {
			return
		}
		editFile(target)

	case tcell.KeyF5:
		if name == "" {
			return
		}
		src := filepath.Join(p.dir, name)
		dstDir := getInactive().dir
		showConfirm(fmt.Sprintf("Скопировать %q в\n%s?", name, dstDir), p, func() {
			dst := filepath.Join(dstDir, name)

			go func() {
				err := copyPath(src, dst)

				app.QueueUpdateDraw(func() {
					if err != nil {
						showMessage("Ошибка копирования: "+err.Error(), p)
					}
					left.Refresh()
					right.Refresh()
				})
			}()
		})

	case tcell.KeyF6:
		if name == "" {
			return
		}
		showInput("Переименовать", "Новое имя:", name, p, func(newName string) {
			oldPath := filepath.Join(p.dir, name)
			newPath := newName
			if !filepath.IsAbs(newPath) {
				newPath = filepath.Join(p.dir, newName)
			}
			if err := os.Rename(oldPath, newPath); err != nil {
				showMessage("Ошибка переименования: "+err.Error(), p)
				return
			}
			left.Refresh()
			right.Refresh()
		})

	case tcell.KeyF7:
		showInput("Создать папку", "Имя папки:", "", p, func(n string) {
			if err := os.Mkdir(filepath.Join(p.dir, n), os.ModePerm); err != nil {
				showMessage("Ошибка создания папки: "+err.Error(), p)
				return
			}
			left.Refresh()
			right.Refresh()
		})

	case tcell.KeyF8:
		if name == "" {
			return
		}
		showConfirm("Удалить "+name+"?", p, func() {
			if err := os.RemoveAll(filepath.Join(p.dir, name)); err != nil {
				showMessage("Ошибка удаления: "+err.Error(), p)
				return
			}
			left.Refresh()
			right.Refresh()
		})
	}
}

func main() {
	app = tview.NewApplication()
	pwd, err := os.Getwd()
	if err != nil {
		log.Fatal(err)
	}

	left = NewFilePanel(pwd)
	right = NewFilePanel(pwd)

	hdr := tview.NewTextView().SetTextAlign(tview.AlignLeft).SetText(" [white:red:b] LUZ MANAGER v1.0 [-:-:-]")
	hdr.SetDynamicColors(true)
	hdr.SetBackgroundColor(tcell.ColorBlack)

	btn := tview.NewTextView().SetDynamicColors(true).SetText(
		" [black:lightcyan]1[-:-]Help  [black:lightcyan]3[-:-]View  " +
			"[black:lightcyan]4[-:-]Edit  [black:lightcyan]5[-:-]Copy  [black:lightcyan]6[-:-]Rename  " +
			"[black:lightcyan]7[-:-]MkFold  [black:lightcyan]8[-:-]Delete  [white:black]  [black:lightcyan]10[-:-]Quit ")
	btn.SetBackgroundColor(tcell.ColorBlack)

	grid := tview.NewGrid().SetRows(1, 0, 1).SetColumns(0, 0)
	grid.AddItem(hdr, 0, 0, 1, 2, 0, 0, false).
		AddItem(left, 1, 0, 1, 1, 0, 0, true).
		AddItem(right, 1, 1, 1, 1, 0, 0, false).
		AddItem(btn, 2, 0, 1, 2, 0, 0, false)

	pages = tview.NewPages().AddPage("main", grid, true, true)
	app.EnableMouse(true)

	app.SetInputCapture(func(e *tcell.EventKey) *tcell.EventKey {
		if e.Key() == tcell.KeyTab {
			if left.HasFocus() {
				app.SetFocus(right)
			} else {
				app.SetFocus(left)
			}
			return nil
		}
		if e.Key() == tcell.KeyF10 {
			app.Stop()
			return nil
		}
		handleFKeys(e.Key())
		return e
	})

	if err := app.SetRoot(pages, true).Run(); err != nil {
		panic(err)
	}
}
