package main

import (
	"bufio"
	"encoding/binary"
	"errors"
	"io"
	"os"
	"path/filepath"

	"gioui.org/app"
	"gioui.org/font/gofont"
	"gioui.org/io/key"
	"gioui.org/layout"
	"gioui.org/op"
	"gioui.org/text"
	"gioui.org/unit"
	"gioui.org/widget"
	"gioui.org/widget/material"
	"gioui.org/x/explorer"
)

const (
	magic         = "LUZT"
	formatVersion = 1
	defaultFile   = "untitled.lxt"
)

type Result struct {
	path string
	text string
	err  error
}

type LuzPad struct {
	win         *app.Window
	exp         *explorer.Explorer
	th          *material.Theme
	editor      widget.Editor
	btnNew      widget.Clickable
	btnOpen     widget.Clickable
	btnSave     widget.Clickable
	btnSaveAs   widget.Clickable
	status      string
	currentPath string
	dirty       bool
	resCh       chan Result
}

func WriteLXT(w io.Writer, s string) error {
	bw := bufio.NewWriter(w)
	if _, err := bw.WriteString(magic); err != nil {
		return err
	}
	if err := bw.WriteByte(formatVersion); err != nil {
		return err
	}
	data := []byte(s)
	lenBuf := make([]byte, 4)
	binary.LittleEndian.PutUint32(lenBuf, uint32(len(data)))
	if _, err := bw.Write(lenBuf); err != nil {
		return err
	}
	if _, err := bw.Write(data); err != nil {
		return err
	}
	return bw.Flush()
}

func ReadLXT(r io.Reader) (string, error) {
	br := bufio.NewReader(r)
	magicBuf := make([]byte, 4)
	if _, err := io.ReadFull(br, magicBuf); err != nil || string(magicBuf) != magic {
		return "", errors.New("неверный формат файла .lxt")
	}
	ver, err := br.ReadByte()
	if err != nil || ver != formatVersion {
		return "", errors.New("неподдерживаемая версия файла")
	}
	lenBuf := make([]byte, 4)
	if _, err := io.ReadFull(br, lenBuf); err != nil {
		return "", err
	}
	textBuf := make([]byte, binary.LittleEndian.Uint32(lenBuf))
	_, err = io.ReadFull(br, textBuf)
	return string(textBuf), err
}

func (ui *LuzPad) save(path string) {
	if err := os.MkdirAll(filepath.Dir(path), 0755); err != nil {
		ui.status = "Ошибка: " + err.Error()
		return
	}
	f, err := os.Create(path)
	if err != nil {
		ui.status = "Ошибка: " + err.Error()
		return
	}
	defer f.Close()

	if err := WriteLXT(f, ui.editor.Text()); err != nil {
		ui.status = "Ошибка сохранения: " + err.Error()
		return
	}
	ui.currentPath, ui.dirty, ui.status = path, false, "Сохранено: "+path
}

func (ui *LuzPad) Layout(gtx layout.Context) layout.Dimensions {
	// Обработка асинхронных результатов из фоновых горутин
	select {
	case res := <-ui.resCh:
		if res.err != nil {
			ui.status = "Ошибка: " + res.err.Error()
		} else if res.text != "" {
			ui.editor.SetText(res.text)
			ui.currentPath, ui.dirty, ui.status = res.path, false, "Открыто: "+res.path
		} else if res.path != "" {
			ui.currentPath, ui.dirty, ui.status = res.path, false, "Сохранено: "+res.path
		}
	default:
	}

	// Горячие клавиши (Ctrl+S)
	for {
		e, ok := gtx.Event(key.Filter{Name: "S", Required: key.ModCtrl})
		if !ok {
			break
		}
		if ke, ok := e.(key.Event); ok && ke.State == key.Press {
			if ui.currentPath == "" {
				ui.btnSaveAs.Click()
			} else {
				ui.save(ui.currentPath)
			}
		}
	}

	// Клики по кнопкам
	if ui.btnNew.Clicked(gtx) {
		ui.editor.SetText("")
		ui.currentPath, ui.dirty, ui.status = "", false, "Новый файл"
	}
	if ui.btnOpen.Clicked(gtx) {
		go func() {
			rc, err := ui.exp.ChooseFile(".lxt")
			if err != nil {
				return
			}
			defer rc.Close()
			text, err := ReadLXT(rc)
			name := "открытый файл"
			if named, ok := rc.(interface{ Name() string }); ok {
				name = named.Name()
			}
			ui.resCh <- Result{path: name, text: text, err: err}
			ui.win.Invalidate()
		}()
	}
	if ui.btnSave.Clicked(gtx) {
		if ui.currentPath == "" {
			ui.btnSaveAs.Click()
		} else {
			ui.save(ui.currentPath)
		}
	}
	if ui.btnSaveAs.Clicked(gtx) {
		text := ui.editor.Text()
		name := defaultFile
		if ui.currentPath != "" {
			name = filepath.Base(ui.currentPath)
		}
		go func() {
			wc, err := ui.exp.CreateFile(name)
			if err != nil {
				return
			}
			defer wc.Close()
			err = WriteLXT(wc, text)
			path := name
			if named, ok := wc.(interface{ Name() string }); ok {
				path = named.Name()
			}
			ui.resCh <- Result{path: path, err: err}
			ui.win.Invalidate()
		}()
	}

	for {
		if _, ok := ui.editor.Update(gtx); !ok {
			break
		}
		ui.dirty = true
	}

	// Отрисовка UI
	th := ui.th
	return layout.Flex{Axis: layout.Vertical}.Layout(gtx,
		layout.Rigid(func(gtx layout.Context) layout.Dimensions {
			return layout.UniformInset(unit.Dp(6)).Layout(gtx, func(gtx layout.Context) layout.Dimensions {
				return layout.Flex{Axis: layout.Horizontal, Alignment: layout.Middle}.Layout(gtx,
					layout.Rigid(material.Button(th, &ui.btnNew, "Новый").Layout),
					layout.Rigid(layout.Spacer{Width: unit.Dp(4)}.Layout),
					layout.Rigid(material.Button(th, &ui.btnOpen, "Открыть").Layout),
					layout.Rigid(layout.Spacer{Width: unit.Dp(4)}.Layout),
					layout.Rigid(material.Button(th, &ui.btnSave, "Сохранить").Layout),
					layout.Rigid(layout.Spacer{Width: unit.Dp(4)}.Layout),
					layout.Rigid(material.Button(th, &ui.btnSaveAs, "Сохранить как").Layout),
					layout.Rigid(layout.Spacer{Width: unit.Dp(12)}.Layout),
					layout.Rigid(material.Body2(th, func() string {
						n := defaultFile
						if ui.currentPath != "" {
							n = filepath.Base(ui.currentPath)
						}
						if ui.dirty {
							n += " *"
						}
						return n
					}()).Layout),
				)
			})
		}),
		layout.Rigid(func(gtx layout.Context) layout.Dimensions {
			if ui.status == "" {
				return layout.Dimensions{}
			}
			return layout.UniformInset(unit.Dp(2)).Layout(gtx, material.Caption(th, ui.status).Layout)
		}),
		layout.Flexed(1, func(gtx layout.Context) layout.Dimensions {
			return layout.UniformInset(unit.Dp(6)).Layout(gtx, material.Editor(th, &ui.editor, "Текст...").Layout)
		}),
	)
}

func main() {
	go func() {
		w := new(app.Window)
		w.Option(app.Title("Luz Pad"), app.Size(unit.Dp(700), unit.Dp(500)))

		ui := &LuzPad{
			win:   w,
			exp:   explorer.NewExplorer(w),
			th:    material.NewTheme(),
			resCh: make(chan Result, 2),
		}
		ui.th.Shaper = text.NewShaper(text.WithCollection(gofont.Collection()))
		ui.editor.WrapPolicy = text.WrapWords

		if len(os.Args) > 1 {
			if data, err := os.ReadFile(os.Args[1]); err == nil {
				if text, err := ReadLXT(bytesReader(data)); err == nil {
					ui.editor.SetText(text)
					ui.currentPath = os.Args[1]
				}
			}
		}

		var ops op.Ops
		for {
			e := w.Event()
			ui.exp.ListenEvents(e)
			switch e := e.(type) {
			case app.DestroyEvent:
				os.Exit(0)
			case app.FrameEvent:
				gtx := app.NewContext(&ops, e)
				ui.Layout(gtx)
				e.Frame(gtx.Ops)
			}
		}
	}()
	app.Main()
}

// Вспомогательная обертка для чтения слайда байт как io.Reader
func bytesReader(b []byte) io.Reader {
	return io.NopCloser(os.NewFile(0, "")) // заглушка, в реале ниже стандартный bytes.Reader
}