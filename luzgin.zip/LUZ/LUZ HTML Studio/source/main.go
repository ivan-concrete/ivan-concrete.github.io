package main

import (
	"gioui.org/app"
	"gioui.org/font/gofont"
	"gioui.org/io/clipboard"
	"gioui.org/layout"
	"gioui.org/op"
	"gioui.org/text"
	"gioui.org/unit"
	"gioui.org/widget"
	"gioui.org/widget/material"
	"gioui.org/x/explorer"
	"image/color"
	"io"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"
)

type MenuType int
const (
	MenuMain MenuType = iota
	MenuText; MenuForms; MenuMedia; MenuStructure; MenuCode
)

type TagSnippet struct {
	Label, Snippet string
	Btn            *widget.Clickable
}

type UI struct {
	Theme       *material.Theme
	explorer    *explorer.Explorer
	currentMenu MenuType
	menuList    layout.List
	htmlEditor  widget.Editor
	filePath    string
	dirty       bool
	status      string
	statusUntil time.Time
	btnBack     widget.Clickable
	sysButtons  map[string]*widget.Clickable
	tagGroups   map[MenuType][]TagSnippet
	asyncEvents chan func()
}

const blankTemplate = "<!DOCTYPE html>\n<html>\n<head>\n<meta charset=\"UTF-8\">\n<title>Документ</title>\n</head>\n<body>\n\n\n\n</body>\n</html>"

var (
	clPrim = color.NRGBA{R: 0x00, G: 0x7A, B: 0xCC, A: 0xFF}
	clSec  = color.NRGBA{R: 0x00, G: 0x96, B: 0x88, A: 0xFF}
	clAcc  = color.NRGBA{R: 0x10, G: 0x7C, B: 0x41, A: 0xFF}
	clDang = color.NRGBA{R: 0xA8, G: 0x00, B: 0x00, A: 0xFF}
	clMut  = color.NRGBA{R: 0x3C, G: 0x3C, B: 0x3C, A: 0xFF}
)

func main() {
	go func() {
		w := new(app.Window)
		w.Option(app.Title("HTML Studio Pro"), app.Size(unit.Dp(1100), unit.Dp(500)), app.MinSize(unit.Dp(860), unit.Dp(400)))
		if err := run(w); err != nil { log.Fatal(err) }
		os.Exit(0)
	}()
	app.Main()
}

func run(w *app.Window) error {
	th := material.NewTheme()
	th.Palette.ContrastBg = clPrim
	th.Shaper = text.NewShaper(text.WithCollection(gofont.Collection()))

	ui := &UI{
		Theme: th, currentMenu: MenuMain, explorer: explorer.NewExplorer(w), asyncEvents: make(chan func(), 10),
		sysButtons: map[string]*widget.Clickable{"new":{},"save":{},"saveAs":{},"load":{},"clear":{},"copy":{},"preview":{},"goText":{},"goForms":{},"goMedia":{},"goStructure":{},"goCode":{}},
	}
	ui.menuList.Axis = layout.Vertical
	ui.htmlEditor.SetText(blankTemplate)
	ui.initTags()

	var ops op.Ops
	for {
		select {
		case f := <-ui.asyncEvents:
			f()
			w.Invalidate()
		default:
			e := w.Event()
			ui.explorer.ListenEvents(e)
			switch e := e.(type) {
			case app.DestroyEvent: return e.Err
			case app.FrameEvent:
				gtx := app.NewContext(&ops, e)
				ui.handleFileActions(w, gtx)
				ui.handleNavigation(gtx)
				ui.handleTagInsertions(gtx)
				
				title := "Без названия — HTML Studio Pro"
				if ui.filePath != "" { title = filepath.Base(ui.filePath) + " — HTML Studio Pro" }
				if ui.dirty { title = "* " + title }
				w.Option(app.Title(title))

				ui.layout(gtx)
				e.Frame(gtx.Ops)
			}
		}
	}
}

func (ui *UI) setStatus(msg string) {
	ui.status = msg
	ui.statusUntil = time.Now().Add(4 * time.Second)
}

func (ui *UI) handleFileActions(w *app.Window, gtx layout.Context) {
	if ui.sysButtons["new"].Clicked(gtx) {
		ui.htmlEditor.SetText(blankTemplate); ui.filePath, ui.dirty = "", false; ui.setStatus("Создан новый шаблон")
	}
	if ui.sysButtons["clear"].Clicked(gtx) {
		ui.htmlEditor.SetText(""); ui.dirty = true; ui.setStatus("Рабочая область очищена")
	}
	if ui.sysButtons["save"].Clicked(gtx) {
		if ui.filePath == "" { ui.saveAs(w) } else { ui.saveTo(ui.filePath) }
	}
	if ui.sysButtons["saveAs"].Clicked(gtx) { ui.saveAs(w) }
	if ui.sysButtons["copy"].Clicked(gtx) {
		gtx.Execute(clipboard.WriteCmd{Data: io.NopCloser(strings.NewReader(ui.htmlEditor.Text()))})
		ui.setStatus("Код скопирован")
	}
	if ui.sysButtons["preview"].Clicked(gtx) {
		if err := ui.previewInBrowser(); err != nil { ui.setStatus("Ошибка: " + err.Error()) } else { ui.setStatus("Экспорт в браузер выполнен") }
	}
	if ui.sysButtons["load"].Clicked(gtx) {
		go func() {
			file, err := ui.explorer.ChooseFile(".html", ".htm", ".txt")
			if err != nil || file == nil { ui.asyncEvents <- func() { ui.setStatus("Выбор отменен") }; w.Invalidate(); return }
			defer file.Close()
			data, _ := io.ReadAll(file)
			name := "Импорт.html"
			if named, ok := file.(interface{ Name() string }); ok { name = named.Name() } else if osFile, ok := file.(*os.File); ok { name = osFile.Name() }
			ui.asyncEvents <- func() {
				ui.htmlEditor.SetText(string(data)); ui.filePath = name; ui.dirty = false; ui.setStatus("Файл открыт: "+filepath.Base(name))
			}
			w.Invalidate()
		}()
	}
}

func (ui *UI) saveAs(w *app.Window) {
	name := "index.html"
	if ui.filePath != "" { name = filepath.Base(ui.filePath) }
	buf := ui.htmlEditor.Text()
	go func() {
		file, err := ui.explorer.CreateFile(name)
		if err != nil { return }
		defer file.Close()
		file.Write([]byte(buf))
		path := name
		if named, ok := file.(interface{ Name() string }); ok { path = named.Name() }
		ui.asyncEvents <- func() { ui.filePath = path; ui.dirty = false; ui.setStatus("Сохранено") }
	}()
}

func (ui *UI) saveTo(path string) {
	if err := os.WriteFile(path, []byte(ui.htmlEditor.Text()), 0644); err != nil { ui.setStatus("Ошибка: "+err.Error()); return }
	ui.dirty = false; ui.setStatus("Сохранено в "+filepath.Base(path))
}

func (ui *UI) previewInBrowser() error {
	tmp := filepath.Join(os.TempDir(), "sandbox_preview.html")
	if err := os.WriteFile(tmp, []byte(ui.htmlEditor.Text()), 0644); err != nil { return err }
	var cmd *exec.Cmd
	switch runtime.GOOS {
	case "windows": cmd = exec.Command("rundll32", "url.dll,FileProtocolHandler", tmp)
	case "darwin":  cmd = exec.Command("open", tmp)
	default:        cmd = exec.Command("xdg-open", tmp)
	}
	return cmd.Start()
}

func (ui *UI) handleNavigation(gtx layout.Context) {
	if ui.btnBack.Clicked(gtx) { ui.currentMenu = MenuMain }
	cats := []struct { b *widget.Clickable; m MenuType }{
		{ui.sysButtons["goText"], MenuText}, {ui.sysButtons["goForms"], MenuForms},
		{ui.sysButtons["goMedia"], MenuMedia}, {ui.sysButtons["goStructure"], MenuStructure}, {ui.sysButtons["goCode"], MenuCode},
	}
	for _, c := range cats {
		if c.b != nil && c.b.Clicked(gtx) { ui.currentMenu = c.m }
	}
}

func (ui *UI) handleTagInsertions(gtx layout.Context) {
	if snips, ok := ui.tagGroups[ui.currentMenu]; ok {
		for _, item := range snips {
			if item.Btn.Clicked(gtx) { ui.htmlEditor.Insert(item.Snippet); ui.dirty = true }
		}
	}
}

func (ui *UI) layout(gtx layout.Context) layout.Dimensions {
	return layout.Inset{Top: 15, Bottom: 10, Left: 15, Right: 15}.Layout(gtx, func(gtx layout.Context) layout.Dimensions {
		return layout.Flex{Axis: layout.Vertical}.Layout(gtx,
			layout.Flexed(1, func(gtx layout.Context) layout.Dimensions {
				return layout.Flex{Axis: layout.Horizontal}.Layout(gtx,
					layout.Rigid(func(gtx layout.Context) layout.Dimensions {
						gtx.Constraints.Min.X, gtx.Constraints.Max.X = gtx.Dp(340), gtx.Dp(340)
						return ui.menuList.Layout(gtx, 1, func(gtx layout.Context, i int) layout.Dimensions { return ui.renderLeftPanel(gtx) })
					}),
					layout.Rigid(layout.Spacer{Width: 20}.Layout),
					layout.Rigid(func(gtx layout.Context) layout.Dimensions {
						gtx.Constraints.Min.X, gtx.Constraints.Max.X = gtx.Dp(180), gtx.Dp(180)
						return ui.renderSystemPanel(gtx)
					}),
					layout.Rigid(layout.Spacer{Width: 20}.Layout),
					layout.Flexed(1, func(gtx layout.Context) layout.Dimensions {
						return widget.Border{Color: clMut, CornerRadius: 4, Width: 1}.Layout(gtx, func(gtx layout.Context) layout.Dimensions {
							return layout.Inset{Top: 8, Bottom: 8, Left: 8, Right: 8}.Layout(gtx, func(gtx layout.Context) layout.Dimensions {
								for ev, ok := ui.htmlEditor.Update(gtx); ok; ev, ok = ui.htmlEditor.Update(gtx) {
									if _, ok := ev.(widget.ChangeEvent); ok { ui.dirty = true }
								}
								return material.Editor(ui.Theme, &ui.htmlEditor, "Начните вводить HTML код...").Layout(gtx)
							})
						})
					}),
				)
			}),
			layout.Rigid(func(gtx layout.Context) layout.Dimensions {
				return layout.Inset{Top: 8}.Layout(gtx, func(gtx layout.Context) layout.Dimensions {
					msg := "Статус: Ожидание"
					if time.Now().Before(ui.statusUntil) { msg = ui.status } else if ui.dirty { msg = "Несохраненные изменения" } else if ui.filePath != "" { msg = "Workspace: " + ui.filePath }
					lbl := material.Caption(ui.Theme, msg); lbl.Color = ui.Theme.Palette.Fg
					return lbl.Layout(gtx)
				})
			}),
		)
	})
}

func (ui *UI) renderLeftPanel(gtx layout.Context) layout.Dimensions {
	if ui.currentMenu == MenuMain {
		return layout.Flex{Axis: layout.Vertical}.Layout(gtx,
			layout.Rigid(func(gtx layout.Context) layout.Dimensions { return material.H6(ui.Theme, "Инструментарий").Layout(gtx) }),
			layout.Rigid(layout.Spacer{Height: 10}.Layout),
			layout.Rigid(func(gtx layout.Context) layout.Dimensions { return ui.btn(gtx, ui.sysButtons["goText"], "Текст и стили", clPrim) }),
			layout.Rigid(func(gtx layout.Context) layout.Dimensions { return ui.btn(gtx, ui.sysButtons["goForms"], "Формы и инпуты", clPrim) }),
			layout.Rigid(func(gtx layout.Context) layout.Dimensions { return ui.btn(gtx, ui.sysButtons["goMedia"], "Медиа и ресурсы", clPrim) }),
			layout.Rigid(func(gtx layout.Context) layout.Dimensions { return ui.btn(gtx, ui.sysButtons["goStructure"], "Архитектура", clPrim) }),
			layout.Rigid(func(gtx layout.Context) layout.Dimensions { return ui.btn(gtx, ui.sysButtons["goCode"], "Сценарии", clPrim) }),
		)
	}
	titles := map[MenuType]string{MenuText: "Стилизация", MenuForms: "Формы", MenuMedia: "Медиакомпоненты", MenuStructure: "Разметка", MenuCode: "Программирование"}
	snips := ui.tagGroups[ui.currentMenu]
	var rows []layout.FlexChild
	rows = append(rows, layout.Rigid(func(gtx layout.Context) layout.Dimensions { return material.H6(ui.Theme, titles[ui.currentMenu]).Layout(gtx) }), layout.Rigid(layout.Spacer{Height: 10}.Layout))
	for i := 0; i < len(snips); i += 3 {
		end := i + 3
		if end > len(snips) { end = len(snips) }
		chunk := snips[i:end]
		rows = append(rows, layout.Rigid(func(gtx layout.Context) layout.Dimensions {
			return layout.Inset{Bottom: 6}.Layout(gtx, func(gtx layout.Context) layout.Dimensions {
				return layout.Flex{Axis: layout.Horizontal}.Layout(gtx, ui.row(chunk)...)
			})
		}))
	}
	rows = append(rows, layout.Rigid(layout.Spacer{Height: 12}.Layout), layout.Rigid(func(gtx layout.Context) layout.Dimensions {
		b := material.Button(ui.Theme, &ui.btnBack, "← Назад"); b.Background = clMut; return b.Layout(gtx)
	}))
	return layout.Flex{Axis: layout.Vertical}.Layout(gtx, rows...)
}

func (ui *UI) row(chunk []TagSnippet) []layout.FlexChild {
	items := make([]layout.FlexChild, 3)
	for i := 0; i < 3; i++ {
		if i < len(chunk) {
			item := chunk[i]
			items[i] = layout.Flexed(1, func(gtx layout.Context) layout.Dimensions {
				return layout.Inset{Right: 4}.Layout(gtx, func(gtx layout.Context) layout.Dimensions {
					b := material.Button(ui.Theme, item.Btn, item.Label); b.Background = clSec; return b.Layout(gtx)
				})
			})
		} else {
			items[i] = layout.Flexed(1, func(gtx layout.Context) layout.Dimensions { return layout.Dimensions{} })
		}
	}
	return items
}

func (ui *UI) renderSystemPanel(gtx layout.Context) layout.Dimensions {
	return layout.Flex{Axis: layout.Vertical}.Layout(gtx,
		layout.Rigid(func(gtx layout.Context) layout.Dimensions { return material.H6(ui.Theme, "Управление").Layout(gtx) }),
		layout.Rigid(layout.Spacer{Height: 10}.Layout),
		layout.Rigid(func(gtx layout.Context) layout.Dimensions { return ui.btn(gtx, ui.sysButtons["new"], "Новый файл", clPrim) }),
		layout.Rigid(func(gtx layout.Context) layout.Dimensions { return ui.btn(gtx, ui.sysButtons["save"], "Сохранить", clPrim) }),
		layout.Rigid(func(gtx layout.Context) layout.Dimensions { return ui.btn(gtx, ui.sysButtons["saveAs"], "Как...", clPrim) }),
		layout.Rigid(func(gtx layout.Context) layout.Dimensions { return ui.btn(gtx, ui.sysButtons["load"], "Открыть", clPrim) }),
		layout.Rigid(func(gtx layout.Context) layout.Dimensions { return ui.btn(gtx, ui.sysButtons["clear"], "Очистить", clDang) }),
		layout.Rigid(layout.Spacer{Height: 12}.Layout),
		layout.Rigid(func(gtx layout.Context) layout.Dimensions { return ui.btn(gtx, ui.sysButtons["copy"], "Буфер", clPrim) }),
		layout.Rigid(func(gtx layout.Context) layout.Dimensions { return ui.btn(gtx, ui.sysButtons["preview"], "Live View 🌐", clAcc) }),
	)
}

func (ui *UI) btn(gtx layout.Context, b *widget.Clickable, t string, bg color.NRGBA) layout.Dimensions {
	return layout.Inset{Bottom: 5}.Layout(gtx, func(gtx layout.Context) layout.Dimensions {
		btn := material.Button(ui.Theme, b, t); btn.Background = bg; return btn.Layout(gtx)
	})
}

func (ui *UI) initTags() {
	ui.tagGroups = map[MenuType][]TagSnippet{
		MenuText: {
			{"<b>", "<b></b>", &widget.Clickable{}}, {"<i>", "<i></i>", &widget.Clickable{}}, {"<u>", "<u></u>", &widget.Clickable{}},
			{"<strong>", "<strong></strong>", &widget.Clickable{}}, {"<em>", "<em></em>", &widget.Clickable{}}, {"<small>", "<small></small>", &widget.Clickable{}},
			{"<mark>", "<mark></mark>", &widget.Clickable{}}, {"<strike>", "<strike></strike>", &widget.Clickable{}}, {"<del>", "<del></del>", &widget.Clickable{}},
			{"<ins>", "<ins></ins>", &widget.Clickable{}}, {"<sub>", "<sub></sub>", &widget.Clickable{}}, {"<sup>", "<sup></sup>", &widget.Clickable{}},
		},
		MenuForms: {
			{"<form>", "<form action=\"\">\n\n</form>", &widget.Clickable{}}, {"<input>", "<input type=\"text\">", &widget.Clickable{}}, {"<submit>", "<input type=\"submit\">", &widget.Clickable{}},
			{"<radio>", "<input type=\"radio\">", &widget.Clickable{}}, {"<checkbox>", "<input type=\"checkbox\">", &widget.Clickable{}}, {"<select>", "<select>\n  <option></option>\n</select>", &widget.Clickable{}},
			{"<textarea>", "<textarea></textarea>", &widget.Clickable{}}, {"<label>", "<label></label>", &widget.Clickable{}}, {"<button>", "<button></button>", &widget.Clickable{}},
		},
		MenuMedia: {
			{"<img>", "<img src=\"\" alt=\"\">", &widget.Clickable{}}, {"<a>", "<a href=\"\"></a>", &widget.Clickable{}}, {"<audio>", "<audio controls></audio>", &widget.Clickable{}},
			{"<video>", "<video controls></video>", &widget.Clickable{}}, {"<iframe>", "<iframe></iframe>", &widget.Clickable{}},
		},
		MenuStructure: {
			{"<h1>", "<h1></h1>", &widget.Clickable{}}, {"<h2>", "<h2></h2>", &widget.Clickable{}}, {"<h3>", "<h3></h3>", &widget.Clickable{}},
			{"<p>", "<p></p>", &widget.Clickable{}}, {"<div>", "<div></div>", &widget.Clickable{}}, {"<span>", "<span></span>", &widget.Clickable{}},
			{"<br>", "<br>\n", &widget.Clickable{}}, {"<hr>", "<hr>\n", &widget.Clickable{}},
		},
		MenuCode: {
			{"<style>", "<style>\n\n</style>", &widget.Clickable{}}, {"<script>", "<script>\n\n</script>", &widget.Clickable{}},
			{"<?php>", "<?php\n\n?>", &widget.Clickable{}}, {"<link>", "<link rel=\"stylesheet\" href=\"\">", &widget.Clickable{}},
		},
	}
}